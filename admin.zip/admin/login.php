<?php
require_once 'config.php';

// Check if already logged in
if (isset($_SESSION['admin_id']) && isset($_SESSION['admin_username'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter username and password';
    } else {
        // Direct password comparison (plain text)
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ? AND password_hash = ?");
        $stmt->execute([$username, $password]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Set session
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_username'] = $user['username'];
            $_SESSION['admin_name'] = $user['full_name'];
            $_SESSION['admin_role'] = $user['role'];
            $_SESSION['admin_email'] = $user['email'];
            $_SESSION['login_time'] = time();
            
            // Update last login
            $updateStmt = $pdo->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?");
            $updateStmt->execute([$user['id']]);
            
            // Redirect to dashboard or previous page
            $redirect = $_SESSION['redirect_after_login'] ?? 'dashboard.php';
            unset($_SESSION['redirect_after_login']);
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid username or password';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Hebron Apartment Gym MS</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body.login-page {
            background: linear-gradient(135deg, #071d49 0%, #1a3a6a 50%, #2a5a8a 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            width: 100%;
            max-width: 420px;
            padding: 20px;
        }
        
        .login-box {
            background: white;
            border-radius: 20px;
            padding: 45px 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
        }
        
        /* Login Logo */
        .login-logo {
            text-align: center;
            margin-bottom: 35px;
        }
        
        .login-logo .logo-img {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 10px;
        }
        
        .login-logo .logo-img img {
            height: 55px;
            width: auto;
        }
        
        .login-logo .logo-img .logo-text {
            font-size: 30px;
            font-weight: 700;
            color: var(--dark);
        }
        
        .login-logo .logo-img .logo-text span {
            color: var(--red);
        }
        
        .login-logo .logo-subtitle {
            color: #888;
            font-size: 14px;
            letter-spacing: 2px;
            text-transform: uppercase;
        }
        
        .login-logo .logo-divider {
            width: 60px;
            height: 3px;
            background: var(--red);
            margin: 12px auto 0;
            border-radius: 2px;
        }
        
        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        
        .form-group label i {
            color: var(--red);
            margin-right: 6px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
            transition: border-color 0.3s;
            background: #f8f9fa;
        }
        
        .form-group input:focus {
            border-color: var(--dark);
            outline: none;
            background: white;
            box-shadow: 0 0 0 3px rgba(7, 29, 73, 0.1);
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--dark);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-login:hover {
            background: #0d2a4a;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(7, 29, 73, 0.3);
        }
        
        .btn-login i {
            font-size: 18px;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            color: #999;
            font-size: 13px;
        }
        
        .login-footer .default-cred {
            background: #f0f2f5;
            padding: 8px 16px;
            border-radius: 6px;
            display: inline-block;
            font-size: 12px;
            color: #666;
        }
        
        .login-footer .default-cred strong {
            color: var(--dark);
        }
        
        /* Alert */
        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .alert-danger i {
            color: #dc2626;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .login-box {
                padding: 30px 20px;
            }
            
            .login-logo .logo-img img {
                height: 40px;
            }
            
            .login-logo .logo-img .logo-text {
                font-size: 24px;
            }
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <!-- Login Logo -->
            <div class="login-logo">
                <div class="logo-img">
                    <img src="../images/logo.png" alt="Tinah Gym Pro">
                    <span class="logo-text"> <span></span></span>
                </div>
                <p class="logo-subtitle">Hebron Apartment Gym MS</p>
                <div class="logo-divider"></div>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username
                    </label>
                    <input type="text" id="username" name="username" placeholder="Enter username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <input type="password" id="password" name="password" placeholder="Enter password" required>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>
            
            <div class="login-footer">
                <p>Default Credentials:</p>
                <span class="default-cred">
                    <strong>Username:</strong> admin &nbsp;|&nbsp; <strong>Password:</strong> admin
                </span>
            </div>
        </div>
    </div>
</body>
</html>