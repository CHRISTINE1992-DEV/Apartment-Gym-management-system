// Image cropper functionality
class ImageCropper {
    constructor(options) {
        this.image = options.image;
        this.container = options.container;
        this.callback = options.callback || function() {};
        this.aspectRatio = options.aspectRatio || 1;
        this.cropBox = null;
        this.startX = 0;
        this.startY = 0;
        this.width = 0;
        this.height = 0;
        this.isDragging = false;
        this.init();
    }
    
    init() {
        // Create crop container
        this.cropContainer = document.createElement('div');
        this.cropContainer.className = 'crop-container';
        this.cropContainer.style.position = 'relative';
        this.cropContainer.style.display = 'inline-block';
        this.cropContainer.style.cursor = 'crosshair';
        
        // Clone image into container
        const img = document.createElement('img');
        img.src = this.image.src;
        img.style.display = 'block';
        img.style.maxWidth = '100%';
        img.style.height = 'auto';
        
        this.cropContainer.appendChild(img);
        this.container.appendChild(this.cropContainer);
        
        // Create crop box
        this.cropBox = document.createElement('div');
        this.cropBox.className = 'crop-box';
        this.cropBox.style.position = 'absolute';
        this.cropBox.style.border = '2px solid #fff';
        this.cropBox.style.boxShadow = '0 0 0 9999px rgba(0,0,0,0.5)';
        this.cropBox.style.cursor = 'move';
        this.cropBox.style.display = 'none';
        this.cropContainer.appendChild(this.cropBox);
        
        // Event listeners
        this.cropContainer.addEventListener('mousedown', this.startCrop.bind(this));
        document.addEventListener('mousemove', this.moveCrop.bind(this));
        document.addEventListener('mouseup', this.endCrop.bind(this));
        
        // Handle resize
        const resizeHandle = document.createElement('div');
        resizeHandle.className = 'resize-handle';
        resizeHandle.style.position = 'absolute';
        resizeHandle.style.bottom = '-5px';
        resizeHandle.style.right = '-5px';
        resizeHandle.style.width = '10px';
        resizeHandle.style.height = '10px';
        resizeHandle.style.background = '#fff';
        resizeHandle.style.border = '1px solid #333';
        resizeHandle.style.cursor = 'nw-resize';
        this.cropBox.appendChild(resizeHandle);
    }
    
    startCrop(e) {
        const rect = this.cropContainer.getBoundingClientRect();
        this.startX = e.clientX - rect.left;
        this.startY = e.clientY - rect.top;
        this.isDragging = true;
        
        // Initialize crop box
        this.cropBox.style.left = this.startX + 'px';
        this.cropBox.style.top = this.startY + 'px';
        this.cropBox.style.width = '0px';
        this.cropBox.style.height = '0px';
        this.cropBox.style.display = 'block';
    }
    
    moveCrop(e) {
        if (!this.isDragging) return;
        
        const rect = this.cropContainer.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        this.width = Math.abs(x - this.startX);
        this.height = Math.abs(y - this.startY);
        
        // Maintain aspect ratio
        if (this.aspectRatio) {
            if (this.width > this.height) {
                this.height = this.width / this.aspectRatio;
            } else {
                this.width = this.height * this.aspectRatio;
            }
        }
        
        const left = Math.min(this.startX, x);
        const top = Math.min(this.startY, y);
        
        this.cropBox.style.left = left + 'px';
        this.cropBox.style.top = top + 'px';
        this.cropBox.style.width = this.width + 'px';
        this.cropBox.style.height = this.height + 'px';
    }
    
    endCrop() {
        if (this.isDragging) {
            this.isDragging = false;
            if (this.width > 10 && this.height > 10) {
                const cropData = this.getCropData();
                if (this.callback) {
                    this.callback(cropData);
                }
            } else {
                this.cropBox.style.display = 'none';
            }
        }
    }
    
    getCropData() {
        const img = this.cropContainer.querySelector('img');
        const rect = img.getBoundingClientRect();
        const naturalWidth = img.naturalWidth || img.width;
        const naturalHeight = img.naturalHeight || img.height;
        
        const boxRect = this.cropBox.getBoundingClientRect();
        const containerRect = this.cropContainer.getBoundingClientRect();
        
        const scaleX = naturalWidth / rect.width;
        const scaleY = naturalHeight / rect.height;
        
        return {
            x: (boxRect.left - containerRect.left) * scaleX,
            y: (boxRect.top - containerRect.top) * scaleY,
            width: boxRect.width * scaleX,
            height: boxRect.height * scaleY,
            naturalWidth: naturalWidth,
            naturalHeight: naturalHeight
        };
    }
    
    cropImage(canvas) {
        const data = this.getCropData();
        canvas.width = data.width;
        canvas.height = data.height;
        const ctx = canvas.getContext('2d');
        const img = this.cropContainer.querySelector('img');
        ctx.drawImage(img, data.x, data.y, data.width, data.height, 0, 0, data.width, data.height);
        return canvas;
    }
}

// Usage example
/*
const cropper = new ImageCropper({
    image: document.getElementById('sourceImage'),
    container: document.getElementById('cropContainer'),
    aspectRatio: 1.5,
    callback: function(data) {
        console.log('Crop data:', data);
    }
});

// To crop and get image data:
const canvas = document.createElement('canvas');
cropper.cropImage(canvas);
const croppedImageData = canvas.toDataURL('image/jpeg');
*/