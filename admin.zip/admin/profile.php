<?php
require_once 'config.php';
requireLogin();

$user = currentUser();
$admin_id = $user['id'] ?? 0;
$admin_name = $user['name'] ?? 'Admin';
$admin_email = $user['email'] ?? '';
$admin_username = $user['username'] ?? '';
$current_page = basename($_SERVER['PHP_SELF']);

$errors = [];
$success = '';

// Get admin user details from admin_users table
$stmt = $pdo->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->execute([$admin_id]);
$admin_user = $stmt->fetch();

if (!$admin_user) {
    $_SESSION['error_message'] = 'User not found.';
    header('Location: dashboard.php');
    exit;
}

// Handle password update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($current_password)) {
        $errors[] = 'Current password is required';
    } elseif (empty($new_password)) {
        $errors[] = 'New password is required';
    } elseif (!validatePassword($new_password)) {
        $errors[] = 'New password must be at least 6 characters';
    } elseif ($new_password !== $confirm_password) {
        $errors[] = 'Passwords do not match';
    } else {
        // Verify current password (plain text comparison for this setup)
        if ($current_password !== $admin_user['password_hash']) {
            $errors[] = 'Current password is incorrect';
        } else {
            // Update password
            $stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE id = ?");
            $stmt->execute([$new_password, $admin_id]);
            
            $_SESSION['success_message'] = 'Password updated successfully!';
            header('Location: profile.php');
            exit;
        }
    }
}

// Handle profile update (optional - if you want to update name/email)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    
    if (empty($full_name)) {
        $errors[] = 'Full name is required';
    } elseif (empty($email) || !validateEmail($email)) {
        $errors[] = 'Valid email is required';
    } else {
        // Check if email already exists for another user
        $stmt = $pdo->prepare("SELECT id FROM admin_users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $admin_id]);
        if ($stmt->fetch()) {
            $errors[] = 'Email already in use by another account';
        } else {
            $stmt = $pdo->prepare("UPDATE admin_users SET full_name = ?, email = ? WHERE id = ?");
            $stmt->execute([$full_name, $email, $admin_id]);
            
            // Update session
            $_SESSION['admin_name'] = $full_name;
            $_SESSION['admin_email'] = $email;
            
            $_SESSION['success_message'] = 'Profile updated successfully!';
            header('Location: profile.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Hebron Apartment Gym MS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f0f2f5;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: var(--dark);
            color: white;
            z-index: 1050;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 700;
        }
        
        .sidebar-header .logo img {
            height: 35px;
            width: auto;
        }
        
        .sidebar-header .logo span {
            color: var(--red);
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .sidebar-nav .nav-section {
            color: rgba(255,255,255,0.3);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 20px 8px;
            font-weight: 700;
        }
        
        .sidebar-nav .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
            cursor: pointer;
        }
        
        .sidebar-nav .nav-link:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .sidebar-nav .nav-link.active {
            background: rgba(230, 57, 70, 0.15);
            color: white;
            border-left-color: var(--red);
        }
        
        .sidebar-nav .nav-link i {
            width: 24px;
            margin-right: 12px;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: white;
            padding: 12px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
            position: sticky;
            top: 0;
            z-index: 1040;
        }
        
        .top-navbar .navbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .top-navbar .toggle-sidebar {
            background: none;
            border: none;
            font-size: 22px;
            cursor: pointer;
            color: #333;
            display: none;
        }
        
        .top-navbar .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .top-navbar .page-title i {
            color: var(--red);
        }
        
        .top-navbar .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .top-navbar .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        
        .top-navbar .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .top-navbar .user-info i {
            font-size: 22px;
            color: #666;
        }
        
        .top-navbar .user-info span {
            color: #333;
            font-weight: 500;
        }
        
        .top-navbar .dropdown-menu-custom {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 8px 0;
            margin-top: 8px;
        }
        
        .top-navbar .user-dropdown:hover .dropdown-menu-custom {
            display: block;
        }
        
        .top-navbar .dropdown-menu-custom a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.2s;
        }
        
        .top-navbar .dropdown-menu-custom a:hover {
            background: #f5f5f5;
        }
        
        .top-navbar .dropdown-menu-custom hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 5px 0;
        }
        
        /* Content Area */
        .content-area {
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .page-header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-header h1 i {
            color: var(--red);
        }
        
        /* Profile Card */
        .profile-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 25px;
            overflow: hidden;
        }
        
        .profile-card .card-header {
            padding: 20px 25px;
            border-bottom: 1px solid #eee;
            background: var(--dark);
            color: white;
        }
        
        .profile-card .card-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
        }
        
        .profile-card .card-header h3 i {
            margin-right: 10px;
        }
        
        .profile-card .card-body {
            padding: 25px;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: var(--dark);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 48px;
            color: white;
        }
        
        .profile-info {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .profile-info h3 {
            color: var(--dark);
            margin-bottom: 5px;
        }
        
        .profile-info p {
            color: #666;
            margin: 0;
        }
        
        .profile-info .badge-role {
            background: var(--red);
            color: white;
            padding: 4px 15px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
            margin-top: 8px;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        
        .form-group label i {
            color: var(--red);
            margin-right: 6px;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
            background: #f8f9fa;
        }
        
        .form-group input:focus {
            border-color: var(--dark);
            outline: none;
            background: white;
            box-shadow: 0 0 0 3px rgba(7, 29, 73, 0.1);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 25px;
            border: none;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: var(--dark);
            color: white;
        }
        
        .btn-primary:hover {
            background: #0d2a4a;
            color: white;
            transform: scale(1.02);
        }
        
        .btn-red {
            background: var(--red);
            color: white;
        }
        
        .btn-red:hover {
            background: #c62828;
            color: white;
            transform: scale(1.02);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            color: white;
        }
        
        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .alert ul {
            margin: 0;
            padding-left: 20px;
        }
        
        .row-custom {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .top-navbar .toggle-sidebar {
                display: block;
            }
            
            .row-custom {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img src="../images/logo.png" alt="Tinah Gym Pro">
            <span>Hebron Apartment Gym MS</span>
        </div>
    </div>
    
    <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-link">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        
        <div class="nav-section">Users</div>
        <a href="add_member.php" class="nav-link">
            <i class="fas fa-user-plus"></i> Add Member
        </a>
        <a href="manage_users.php" class="nav-link">
            <i class="fas fa-users"></i> Manage Users
        </a>
        
        <div class="nav-section">Classes</div>
        <a href="manage_classes.php" class="nav-link">
            <i class="fas fa-dumbbell"></i> Manage Classes
        </a>
        
        <div class="nav-section">Finance</div>
        <a href="manage_payments.php" class="nav-link">
            <i class="fas fa-credit-card"></i> Manage Payments
        </a>
        
        <div class="nav-section">Reports</div>
        <a href="reports.php" class="nav-link">
            <i class="fas fa-chart-bar"></i> Reports
        </a>
        
        <div class="nav-section">Account</div>
        <a href="profile.php" class="nav-link active">
            <i class="fas fa-user"></i> Profile
        </a>
        <a href="logout.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </nav>
</aside>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Navbar -->
    <nav class="top-navbar">
        <div class="navbar-left">
            <button class="toggle-sidebar" id="toggleSidebar">
                <i class="fas fa-bars"></i>
            </button>
            <span class="page-title">
                <i class="fas fa-chevron-right"></i> Profile
            </span>
        </div>
        
        <div class="navbar-right">
            <div class="user-dropdown">
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo htmlspecialchars($admin_name); ?></span>
                    <i class="fas fa-chevron-down" style="font-size:12px;color:#999;"></i>
                </div>
                <div class="dropdown-menu-custom">
                    <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                    <a href="#"><i class="fas fa-cog"></i> Settings</a>
                    <hr>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Content Area -->
    <div class="content-area">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="page-header">
            <h1><i class="fas fa-user-circle"></i> My Profile</h1>
        </div>
        
        <div class="row-custom">
            <!-- Profile Information -->
            <div class="profile-card">
                <div class="card-header">
                    <h3><i class="fas fa-user"></i> Profile Information</h3>
                </div>
                <div class="card-body">
                    <div class="profile-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    
                    <div class="profile-info">
                        <h3><?php echo htmlspecialchars($admin_user['full_name'] ?? $admin_user['username']); ?></h3>
                        <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($admin_user['email']); ?></p>
                        <p><i class="fas fa-user-tag"></i> @<?php echo htmlspecialchars($admin_user['username']); ?></p>
                        <span class="badge-role"><?php echo ucfirst($admin_user['role'] ?? 'Admin'); ?></span>
                    </div>
                    
                    <hr>
                    
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="full_name"><i class="fas fa-user"></i> Full Name</label>
                            <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($admin_user['full_name'] ?? ''); ?>" placeholder="Enter full name">
                        </div>
                        
                        <div class="form-group">
                            <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin_user['email']); ?>" placeholder="Enter email address">
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Change Password -->
            <div class="profile-card">
                <div class="card-header">
                    <h3><i class="fas fa-key"></i> Change Password</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="current_password"><i class="fas fa-lock"></i> Current Password</label>
                            <input type="password" id="current_password" name="current_password" placeholder="Enter current password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password"><i class="fas fa-lock"></i> New Password</label>
                            <input type="password" id="new_password" name="new_password" placeholder="Enter new password (min 6 characters)" required>
                            <small style="color: #888; font-size: 12px;">Minimum 6 characters</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password"><i class="fas fa-check-circle"></i> Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password" required>
                        </div>
                        
                        <button type="submit" name="update_password" class="btn btn-red">
                            <i class="fas fa-key"></i> Update Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Account Information -->
        <div class="profile-card">
            <div class="card-header">
                <h3><i class="fas fa-info-circle"></i> Account Information</h3>
            </div>
            <div class="card-body">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <strong style="color: var(--dark);">Username:</strong>
                        <p style="color: #666; margin: 5px 0;"><?php echo htmlspecialchars($admin_user['username']); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--dark);">Role:</strong>
                        <p style="color: #666; margin: 5px 0;"><?php echo ucfirst($admin_user['role'] ?? 'Admin'); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--dark);">Account Created:</strong>
                        <p style="color: #666; margin: 5px 0;"><?php echo date('M d, Y H:i', strtotime($admin_user['created_at'])); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--dark);">Last Login:</strong>
                        <p style="color: #666; margin: 5px 0;"><?php echo $admin_user['last_login'] ? date('M d, Y H:i', strtotime($admin_user['last_login'])) : 'Never'; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toggle Sidebar Script -->
<script>
    document.getElementById('toggleSidebar').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
    });
</script>

</body>
</html>