<?php
require_once 'config.php';

$user = currentUser();
$admin_name = $user['name'] ?? 'Admin';
$current_page = basename($_SERVER['PHP_SELF']);

// Get statistics
$stats = [];

// Total members
$stmt = $pdo->query("SELECT COUNT(*) as total FROM members");
$stats['total_members'] = $stmt->fetch()['total'];

// Active members
$stmt = $pdo->query("SELECT COUNT(*) as total FROM members WHERE membership_status = 'Active'");
$stats['active_members'] = $stmt->fetch()['total'];

// Total classes
$stmt = $pdo->query("SELECT COUNT(*) as total FROM classes WHERE status = 'Active'");
$stats['total_classes'] = $stmt->fetch()['total'];

// Total payments
$stmt = $pdo->query("SELECT COUNT(*) as total FROM payments WHERE status = 'Completed'");
$stats['total_payments'] = $stmt->fetch()['total'];

// Revenue
$stmt = $pdo->query("SELECT SUM(amount) as total FROM payments WHERE status = 'Completed' AND MONTH(payment_date) = MONTH(NOW())");
$stats['monthly_revenue'] = $stmt->fetch()['total'] ?? 0;

// Recent members
$stmt = $pdo->query("SELECT * FROM members ORDER BY created_at DESC LIMIT 5");
$recent_members = $stmt->fetchAll();

// Recent payments
$stmt = $pdo->query("SELECT * FROM payments ORDER BY payment_date DESC LIMIT 5");
$recent_payments = $stmt->fetchAll();

// Chart data
// Members by membership type
$stmt = $pdo->query("SELECT membership_type, COUNT(*) as count FROM members GROUP BY membership_type");
$membership_data = $stmt->fetchAll();
$membership_labels = array_column($membership_data, 'membership_type');
$membership_counts = array_column($membership_data, 'count');

// Monthly revenue for last 6 months
$stmt = $pdo->query("
    SELECT DATE_FORMAT(payment_date, '%b') as month, SUM(amount) as total 
    FROM payments 
    WHERE status = 'Completed' 
    AND payment_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(payment_date, '%b')
    ORDER BY payment_date
");
$revenue_data = $stmt->fetchAll();
$revenue_labels = array_column($revenue_data, 'month');
$revenue_amounts = array_column($revenue_data, 'total');

// Class bookings
$stmt = $pdo->query("
    SELECT c.class_name, COUNT(cb.id) as bookings 
    FROM classes c
    LEFT JOIN class_bookings cb ON c.id = cb.class_id
    GROUP BY c.id
    LIMIT 5
");
$class_data = $stmt->fetchAll();
$class_labels = array_column($class_data, 'class_name');
$class_counts = array_column($class_data, 'bookings');

// Check if any member page is active
$is_member_page = in_array($current_page, ['add_member.php', 'manage_members.php']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Hebron Apartment Gym MS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        body {
            background: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 260px;
            background: var(--dark);
            color: white;
            z-index: 1050;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 22px;
            font-weight: 700;
        }
        
        .sidebar-header .logo img {
            height: 40px;
            width: auto;
        }
        
        .sidebar-header .logo span {
            color: var(--red);
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .sidebar-nav .nav-section {
            color: rgba(255,255,255,0.3);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 20px 8px;
            font-weight: 700;
        }
        
        .sidebar-nav .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
            cursor: pointer;
        }
        
        .sidebar-nav .nav-link:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .sidebar-nav .nav-link.active {
            background: rgba(230, 57, 70, 0.15);
            color: white;
            border-left-color: var(--red);
        }
        
        .sidebar-nav .nav-link i {
            width: 24px;
            margin-right: 12px;
        }
        
        .sidebar-nav .nav-link .arrow {
            margin-left: auto;
            transition: transform 0.3s;
        }
        
        .sidebar-nav .nav-link .arrow.open {
            transform: rotate(90deg);
        }
        
        /* Submenu */
        .sidebar-nav .submenu {
            list-style: none;
            padding-left: 0;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
        
        .sidebar-nav .submenu.open {
            max-height: 500px;
        }
        
        .sidebar-nav .submenu li a {
            display: flex;
            align-items: center;
            padding: 10px 20px 10px 56px;
            color: rgba(255,255,255,0.6);
            text-decoration: none;
            transition: all 0.3s;
            font-size: 14px;
        }
        
        .sidebar-nav .submenu li a:hover {
            color: white;
            background: rgba(255,255,255,0.05);
        }
        
        .sidebar-nav .submenu li a.active {
            color: white;
            background: rgba(230, 57, 70, 0.1);
            border-left: 3px solid var(--red);
        }
        
        .sidebar-nav .submenu li a i {
            width: 20px;
            margin-right: 10px;
            font-size: 14px;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: white;
            padding: 12px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
            position: sticky;
            top: 0;
            z-index: 1040;
        }
        
        .top-navbar .navbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .top-navbar .toggle-sidebar {
            background: none;
            border: none;
            font-size: 22px;
            cursor: pointer;
            color: #333;
            display: none;
        }
        
        .top-navbar .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .top-navbar .page-title i {
            color: var(--red);
        }
        
        .top-navbar .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .top-navbar .notifications {
            position: relative;
            cursor: pointer;
            font-size: 20px;
            color: #666;
        }
        
        .top-navbar .notifications .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--red);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 50%;
        }
        
        .top-navbar .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        
        .top-navbar .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .top-navbar .user-info i {
            font-size: 22px;
            color: #666;
        }
        
        .top-navbar .user-info span {
            color: #333;
            font-weight: 500;
        }
        
        .top-navbar .dropdown-menu-custom {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 8px 0;
            margin-top: 8px;
        }
        
        .top-navbar .user-dropdown:hover .dropdown-menu-custom {
            display: block;
        }
        
        .top-navbar .dropdown-menu-custom a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.2s;
        }
        
        .top-navbar .dropdown-menu-custom a:hover {
            background: #f5f5f5;
        }
        
        .top-navbar .dropdown-menu-custom hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 5px 0;
        }
        
        /* Content Area */
        .content-area {
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .page-header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-header h1 i {
            color: var(--red);
        }
        
        .page-header span {
            color: #666;
            font-size: 16px;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
        }
        
       .stat-icon {
    width: 55px;
    height: 55px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    color: white;
    flex-shrink: 0;
}

.stat-icon img {
    width: 30px;
    height: 30px;
    object-fit: contain;
    filter: brightness(0) invert(1);
}

.stat-icon i {
    font-size: 26px;
    color: white;
}
        .stat-info h3 {
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 2px;
            color: var(--dark);
        }
        
        .stat-info p {
            color: #666;
            font-size: 14px;
            margin: 0;
        }
        
        .stat-info small {
            color: #888;
            font-size: 12px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            margin-bottom: 25px;
        }
        
        .card-header {
            padding: 18px 25px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: transparent;
        }
        
        .card-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }
        
        .card-header h3 i {
            color: var(--red);
            margin-right: 8px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* Tables */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table thead th {
            background: #f8f9fa;
            font-weight: 600;
            color: #555;
            font-size: 13px;
            text-transform: uppercase;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Badges */
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        
        .badge-danger {
            background: #f8d7da;
            color: #721c24;
        }
        
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .badge-info {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        /* Buttons */
        .btn-sm {
            padding: 5px 15px;
            font-size: 12px;
            border-radius: 20px;
            border: none;
        }
        
        .btn-primary {
            background: var(--dark);
            color: white;
        }
        
        .btn-primary:hover {
            background: #0d2a4a;
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            color: white;
        }
        
        /* Chart containers */
        .chart-container {
            position: relative;
            height: 250px;
        }
        
        /* Row & Col */
        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }
        
        .col {
            min-width: 0;
        }
        
        /* Alert */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .row {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .top-navbar .toggle-sidebar {
                display: block;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 576px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .content-area {
                padding: 15px;
            }
            
            .top-navbar {
                padding: 10px 15px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img src="../images/logo.png" alt="Tinah Gym Pro">
            <span>Hebron Apartment Gym MS</span>
        </div>
    </div>
    
    <nav class="sidebar-nav">
        <!-- Dashboard -->
        <a href="dashboard.php" class="nav-link <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        
        <!-- Users Section with Collapsible Submenu -->
        <div class="nav-section">Users</div>
        
        <!-- Collapsible Parent - Members -->
        <a href="#" class="nav-link <?php echo $is_member_page ? 'active' : ''; ?>" onclick="toggleSubmenu(event)">
            <i class="fas fa-users"></i> Members
            <i class="fas fa-chevron-right arrow <?php echo $is_member_page ? 'open' : ''; ?>"></i>
        </a>
        
        <ul class="submenu <?php echo $is_member_page ? 'open' : ''; ?>">
            <li>
                <a href="add_member.php" class="<?php echo $current_page === 'add_member.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-plus"></i> Add Member
                </a>
            </li>
            <li>
                <a href="manage_members.php" class="<?php echo $current_page === 'manage_members.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-edit"></i> Manage Members
                </a>
            </li>
        </ul>
        
        <!-- Classes Section -->
        <div class="nav-section">Classes</div>
        <a href="manage_classes.php" class="nav-link <?php echo $current_page === 'manage_classes.php' ? 'active' : ''; ?>">
            <i class="fas fa-dumbbell"></i> Manage Classes
        </a>
        
        <!-- Finance Section -->
        <div class="nav-section">Finance</div>
        <a href="manage_payments.php" class="nav-link <?php echo $current_page === 'manage_payments.php' ? 'active' : ''; ?>">
            <i class="fas fa-credit-card"></i> Manage Payments
        </a>
        
        <!-- Reports Section -->
        <div class="nav-section">Reports</div>
        <a href="reports.php" class="nav-link <?php echo $current_page === 'reports.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Reports
        </a>
        
        <!-- Account Section -->
        <div class="nav-section">Profile</div>
        <a href="profile.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i> Profile
        </a>
        <div class="nav-section">Account</div>
        <a href="logout.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </nav>
</aside>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Navbar -->
    <nav class="top-navbar">
        <div class="navbar-left">
            <button class="toggle-sidebar" id="toggleSidebar">
                <i class="fas fa-bars"></i>
            </button>
            <span class="page-title">
                <i class="fas fa-chevron-right"></i> Dashboard
            </span>
        </div>
        
        <div class="navbar-right">
            <div class="notifications">
                <i class="fas fa-bell"></i>
                <span class="badge">0</span>
            </div>
            
            <div class="user-dropdown">
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo htmlspecialchars($admin_name); ?></span>
                    <i class="fas fa-chevron-down" style="font-size:12px;color:#999;"></i>
                </div>
                <div class="dropdown-menu-custom">
                    <a href="#"><i class="fas fa-user"></i> Profile</a>
                    <a href="#"><i class="fas fa-cog"></i> Settings</a>
                    <hr>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Content Area -->
    <div class="content-area">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <div class="page-header">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <span>Welcome, <?php echo htmlspecialchars($admin_name); ?></span>
        </div>
        
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon" style="background: #4a90d9;">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_members']; ?></h3>
                    <p>Total Members</p>
                    <small><?php echo $stats['active_members']; ?> active</small>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: #28a745;">
                    <i class="fas fa-dumbbell"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_classes']; ?></h3>
                    <p>Active Classes</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: #ffc107;">
                    <i class="fas fa-credit-card"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_payments']; ?></h3>
                    <p>Total Payments</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: #17a2b8;">
    <img src="../images/mpesalogo.png" alt="Revenue" style="width: 38px; height: 38px; filter: brightness(0) invert(1);">
</div>
                <div class="stat-info">
                    <h3>Ksh<?php echo number_format($stats['monthly_revenue'], 2); ?></h3>
                    <p>Monthly Revenue</p>
                </div>
            </div>
        </div>
        
        <!-- Charts Row -->
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Members by Type</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="membershipChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-dollar-sign"></i> Monthly Revenue</h3>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tables Row -->
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-plus"></i> Recent Members</h3>
                        <a href="manage_members.php" class="btn btn-primary btn-sm">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Membership</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_members as $member): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                                        <td><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($member['membership_type']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $member['membership_status'] === 'Active' ? 'success' : 'danger'; ?>">
                                                <?php echo $member['membership_status']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-credit-card"></i> Recent Payments</h3>
                        <a href="manage_payments.php" class="btn btn-primary btn-sm">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Member</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_payments as $payment): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($payment['member_id'] ?? 'N/A'); ?></td>
                                        <td>Ksh<?php echo number_format($payment['amount'], 2); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $payment['status'] === 'Completed' ? 'success' : 'warning'; ?>">
                                                <?php echo $payment['status']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Scripts -->
<script>
    // Membership Chart
    const ctx1 = document.getElementById('membershipChart').getContext('2d');
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($membership_labels); ?>,
            datasets: [{
                label: 'Members',
                data: <?php echo json_encode($membership_counts); ?>,
                backgroundColor: ['#4a90d9', '#28a745', '#ffc107', '#17a2b8', '#dc3545'],
                borderColor: '#fff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            }
        }
    });
    
    // Revenue Chart
    const ctx2 = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx2, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($revenue_labels); ?>,
            datasets: [{
                label: 'Revenue (KES)',
                data: <?php echo json_encode($revenue_amounts); ?>,
                backgroundColor: 'rgba(23, 162, 184, 0.2)',
                borderColor: '#17a2b8',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            }
        }
    });
    
    // Toggle Sidebar
    document.getElementById('toggleSidebar').addEventListener('click', function() {
        document.getElementById('sidebar').classList.toggle('active');
    });
    
    // Toggle Submenu Function
    function toggleSubmenu(event) {
        event.preventDefault();
        const parent = event.currentTarget;
        const submenu = parent.nextElementSibling;
        const arrow = parent.querySelector('.arrow');
        
        submenu.classList.toggle('open');
        arrow.classList.toggle('open');
    }
</script>

</body>
</html>