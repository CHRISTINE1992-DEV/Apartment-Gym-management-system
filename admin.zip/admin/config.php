<?php
// ============================================
// CONFIGURATION & BOOTSTRAP
// ============================================

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'techcod2_gym_management');
define('DB_PASS', 'tinahgym@2026');
define('DB_NAME', 'techcod2_gym_management');
define('SITE_NAME', 'Tinah Gym Pro');
define('SITE_URL', 'https://tinahgyms.co.ke/');
define('UPLOAD_PATH', __DIR__ . '/uploads/');

// ============================================
// DATABASE CONNECTION
// ============================================
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ============================================
// AUTHENTICATION FUNCTIONS (Admin & User)
// ============================================

// Check if admin is logged in
function isLoggedIn() {
    return isset($_SESSION['admin_id']) && isset($_SESSION['admin_username']);
}

// Check if user is logged in (for frontend)
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

// Get current admin user
function currentUser() {
    return [
        'id' => $_SESSION['admin_id'] ?? null,
        'username' => $_SESSION['admin_username'] ?? null,
        'name' => $_SESSION['admin_name'] ?? null,
        'role' => $_SESSION['admin_role'] ?? null,
        'email' => $_SESSION['admin_email'] ?? null
    ];
}

// Get current frontend user
function currentFrontendUser() {
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? null,
        'email' => $_SESSION['email'] ?? null,
        'full_name' => $_SESSION['full_name'] ?? null,
        'role' => $_SESSION['role'] ?? null,
        'profile_image' => $_SESSION['profile_image'] ?? null
    ];
}

// Require admin login
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        if (ob_get_level()) ob_clean();
        header('Location: login.php');
        exit;
    }
}

// Require user login (frontend)
function requireUserLogin() {
    if (!isUserLoggedIn()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        if (ob_get_level()) ob_clean();
        header('Location: login.php');
        exit;
    }
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Require admin role
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: dashboard.php');
        exit;
    }
}

// Redirect function
function redirect($url) {
    if (ob_get_level()) ob_clean();
    header('Location: ' . $url);
    exit;
}

// Flash messages
function setFlashMessage($type, $message) {
    $_SESSION['flash_message'] = ['type' => $type, 'message' => $message];
}

function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $msg;
    }
    return null;
}

// Auto-authenticate for admin pages (skip login page)
$skip_auth = ['login.php', 'register.php', 'logout.php', 'index.php'];
$current_page = basename($_SERVER['PHP_SELF']);
if (!in_array($current_page, $skip_auth)) {
    requireLogin();
}

// ============================================
// HELPER FUNCTIONS
// ============================================

// Sanitize input
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)));
}

// Validate email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Validate password (min 6 characters)
function validatePassword($password) {
    return strlen($password) >= 6;
}

// Hash password
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Verify password
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Generate random token
function generateToken() {
    return bin2hex(random_bytes(32));
}

// Generate unique ID for members
function generateId($prefix) {
    global $pdo;
    $count = 1;
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM members WHERE member_id LIKE ?");
    $stmt->execute([$prefix . '%']);
    $total = $stmt->fetch()['total'];
    $count = $total + 1;
    return $prefix . str_pad($count, 3, '0', STR_PAD_LEFT);
}

// Upload file function
function uploadFile($file, $targetDir, $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']) {
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_ext, $allowedTypes) || $file['size'] > 10000000) {
        return false;
    }
    $new_name = uniqid() . '.' . $file_ext;
    if (move_uploaded_file($file['tmp_name'], $targetDir . $new_name)) {
        return $new_name;
    }
    return false;
}

// Time ago function
function timeAgo($timestamp) {
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    $minutes = round($seconds / 60);
    $hours = round($seconds / 3600);
    $days = round($seconds / 86400);
    $weeks = round($seconds / 604800);
    $months = round($seconds / 2629440);
    $years = round($seconds / 31553280);
    
    if($seconds <= 60){
        return "Just Now";
    } else if($minutes <= 60){
        return ($minutes==1)?'1 minute ago':$minutes.' minutes ago';
    } else if($hours <= 24){
        return ($hours==1)?'1 hour ago':$hours.' hours ago';
    } else if($days <= 7){
        return ($days==1)?'1 day ago':$days.' days ago';
    } else if($weeks <= 4.3){
        return ($weeks==1)?'1 week ago':$weeks.' weeks ago';
    } else if($months <= 12){
        return ($months==1)?'1 month ago':$months.' months ago';
    } else {
        return ($years==1)?'1 year ago':$years.' years ago';
    }
}

// Create upload directories
$uploadDirs = ['profiles/', 'documents/', 'posters/', 'thumbnails/', 'movies/', 'courses/'];
foreach ($uploadDirs as $dir) {
    $fullPath = UPLOAD_PATH . $dir;
    if (!file_exists($fullPath)) {
        mkdir($fullPath, 0777, true);
    }
}
?>