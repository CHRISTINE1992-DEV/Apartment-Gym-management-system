<?php
require_once 'config.php';

$user = currentUser();
$admin_name = $user['name'] ?? 'Admin';
$current_page = basename($_SERVER['PHP_SELF']);

$errors = [];
$success = '';

// Get all active members for dropdown
$stmt = $pdo->query("SELECT id, member_id, first_name, last_name FROM members WHERE membership_status = 'Active' ORDER BY first_name");
$members = $stmt->fetchAll();

// Get all active classes for dropdown
$stmt = $pdo->query("SELECT id, class_name FROM classes WHERE status = 'Active' ORDER BY class_name");
$classes = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $member_id = $_POST['member_id'] ?? '';
    $amount = $_POST['amount'] ?? '';
    $payment_method = $_POST['payment_method'] ?? 'Cash';
    $payment_type = $_POST['payment_type'] ?? 'Membership';
    $class_id = $_POST['class_id'] ?? '';
    $reference_number = $_POST['reference_number'] ?? '';
    $phone_number = $_POST['phone_number'] ?? '';
    $status = $_POST['status'] ?? 'Completed';
    $notes = $_POST['notes'] ?? '';
    $payment_date = $_POST['payment_date'] ?? date('Y-m-d H:i:s');
    
    // Validate
    if (empty($member_id)) {
        $errors[] = 'Please select a member';
    }
    
    if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
        $errors[] = 'Please enter a valid amount';
    }
    
    if (empty($payment_method)) {
        $errors[] = 'Please select a payment method';
    }
    
    if (empty($payment_type)) {
        $errors[] = 'Please select a payment type';
    }
    
    // If payment type is Class, validate class selection
    if ($payment_type === 'Class' && empty($class_id)) {
        $errors[] = 'Please select a class';
    }
    
    // If payment type is not Class, clear class_id
    if ($payment_type !== 'Class') {
        $class_id = null;
    }
    
    if (empty($errors)) {
        // Generate reference number if not provided
        if (empty($reference_number)) {
            $reference_number = 'PAY-' . strtoupper(uniqid());
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO payments (member_id, amount, payment_method, payment_type, 
            reference_number, phone_number, status, notes, payment_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $member_id,
            $amount,
            $payment_method,
            $payment_type,
            $reference_number,
            $phone_number,
            $status,
            $notes,
            $payment_date
        ]);
        
        $_SESSION['success_message'] = 'Payment added successfully! Reference: ' . $reference_number;
        header('Location: manage_payments.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Payment - Hebron Apartment Gym MS</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f0f2f5;
        }
        
        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--dark);
            color: white;
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            transition: transform 0.3s ease;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header .logo {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-header .logo img {
            height: 40px;
            width: auto;
        }
        
        .sidebar-header .logo span {
            color: var(--red);
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .sidebar-nav ul {
            list-style: none;
        }
        
        .sidebar-nav li {
            margin-bottom: 5px;
        }
        
        .sidebar-nav .nav-section {
            color: rgba(255,255,255,0.3);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 20px 8px;
            font-weight: 700;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .sidebar-nav a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .sidebar-nav a.active {
            background: rgba(230, 57, 70, 0.15);
            color: white;
            border-left-color: var(--red);
        }
        
        .sidebar-nav a i {
            width: 24px;
            margin-right: 12px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #333;
            display: none;
        }
        
        .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-title i {
            color: var(--red);
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .notifications {
            position: relative;
            cursor: pointer;
        }
        
        .notifications .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--red);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 50%;
        }
        
        .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-info i {
            font-size: 20px;
            color: #666;
        }
        
        .user-info span {
            color: #333;
        }
        
        .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 8px 0;
            margin-top: 8px;
        }
        
        .user-dropdown:hover .dropdown-menu {
            display: block;
        }
        
        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.2s;
        }
        
        .dropdown-menu a:hover {
            background: #f5f5f5;
        }
        
        .dropdown-menu hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 5px 0;
        }
        
        /* Content Area */
        .content-area {
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .page-header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-header h1 i {
            color: var(--red);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 25px;
            border: none;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: var(--dark);
            color: white;
        }
        
        .btn-primary:hover {
            background: #0d2a4a;
            color: white;
        }
        
        .btn-secondary {
            background: var(--light);
            color: white;
        }
        
        .btn-secondary:hover {
            background: #1a8cd8;
            color: white;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
            color: white;
        }
        
        .btn-danger {
            background: var(--red);
            color: white;
        }
        
        .btn-danger:hover {
            background: #c62828;
            color: white;
        }
        
        /* Card */
        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 30px;
        }
        
        /* Form */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--dark);
            outline: none;
        }
        
        .form-group textarea {
            resize: vertical;
        }
        
        .form-group .full-width {
            grid-column: 1 / -1;
        }
        
        .required {
            color: var(--red);
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert ul {
            margin: 0;
            padding-left: 20px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="../images/logo.png" alt="Tinah Gym Pro">
                    <span>Tinah Pro</span>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    
                    <li class="nav-section">Users</li>
                    <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                    <li><a href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                    
                    <li class="nav-section">Classes</li>
                    <li><a href="manage_classes.php"><i class="fas fa-dumbbell"></i> Manage Classes</a></li>
                    
                    <li class="nav-section">Finance</li>
                    <li><a href="manage_payments.php"><i class="fas fa-credit-card"></i> Manage Payments</a></li>
                    <li><a href="add_payment.php" class="active"><i class="fas fa-plus-circle"></i> Add Payment</a></li>
                    
                    <li class="nav-section">Reports</li>
                    <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    
                    <li class="nav-section">Account</li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <nav class="top-navbar">
                <div class="navbar-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="page-title">
                        <i class="fas fa-chevron-right"></i> Add Payment
                    </span>
                </div>
                
                <div class="navbar-right">
                    <div class="notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge">0</span>
                    </div>
                    
                    <div class="user-dropdown">
                        <div class="user-info">
                            <i class="fas fa-user-circle"></i>
                            <span><?php echo htmlspecialchars($admin_name); ?></span>
                            <i class="fas fa-chevron-down" style="font-size:12px;color:#999;"></i>
                        </div>
                        <div class="dropdown-menu">
                            <a href="#"><i class="fas fa-user"></i> Profile</a>
                            <a href="#"><i class="fas fa-cog"></i> Settings</a>
                            <hr>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Content Area -->
            <div class="content-area">
                <div class="page-header">
                    <h1><i class="fas fa-plus-circle"></i> Add New Payment</h1>
                    <a href="manage_payments.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Payments
                    </a>
                </div>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="form-grid">
                                <!-- Member Selection -->
                                <div class="form-group">
                                    <label for="member_id">Select Member <span class="required">*</span></label>
                                    <select id="member_id" name="member_id" required>
                                        <option value="">-- Select Member --</option>
                                        <?php foreach ($members as $member): ?>
                                            <option value="<?php echo $member['id']; ?>" <?php echo (isset($_POST['member_id']) && $_POST['member_id'] == $member['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($member['member_id'] . ' - ' . $member['first_name'] . ' ' . $member['last_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Amount -->
                                <div class="form-group">
                                    <label for="amount">Amount (Ksh) <span class="required">*</span></label>
                                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" value="<?php echo htmlspecialchars($_POST['amount'] ?? ''); ?>" placeholder="Enter amount" required>
                                </div>
                                
                                <!-- Payment Method -->
                                <div class="form-group">
                                    <label for="payment_method">Payment Method <span class="required">*</span></label>
                                    <select id="payment_method" name="payment_method" required>
                                        <option value="Cash" <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] === 'Cash') ? 'selected' : ''; ?>>Cash</option>
                                        <option value="Credit Card" <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] === 'Credit Card') ? 'selected' : ''; ?>>Credit Card</option>
                                        <option value="Debit Card" <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] === 'Debit Card') ? 'selected' : ''; ?>>Debit Card</option>
                                        <option value="Bank Transfer" <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] === 'Bank Transfer') ? 'selected' : ''; ?>>Bank Transfer</option>
                                        <option value="Online" <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] === 'Online') ? 'selected' : ''; ?>>Online</option>
                                        <option value="M-Pesa" <?php echo (isset($_POST['payment_method']) && $_POST['payment_method'] === 'M-Pesa') ? 'selected' : ''; ?>>M-Pesa</option>
                                    </select>
                                </div>
                                
                                <!-- Payment Type -->
                                <div class="form-group">
                                    <label for="payment_type">Payment Type <span class="required">*</span></label>
                                    <select id="payment_type" name="payment_type" required>
                                        <option value="Membership" <?php echo (isset($_POST['payment_type']) && $_POST['payment_type'] === 'Membership') ? 'selected' : ''; ?>>Membership</option>
                                        <option value="Class" <?php echo (isset($_POST['payment_type']) && $_POST['payment_type'] === 'Class') ? 'selected' : ''; ?>>Class</option>
                                        <option value="Personal Training" <?php echo (isset($_POST['payment_type']) && $_POST['payment_type'] === 'Personal Training') ? 'selected' : ''; ?>>Personal Training</option>
                                        <option value="Other" <?php echo (isset($_POST['payment_type']) && $_POST['payment_type'] === 'Other') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                
                                <!-- Class Selection (conditional) -->
                                <div class="form-group" id="class_group">
                                    <label for="class_id">Select Class</label>
                                    <select id="class_id" name="class_id">
                                        <option value="">-- Select Class --</option>
                                        <?php foreach ($classes as $class): ?>
                                            <option value="<?php echo $class['id']; ?>" <?php echo (isset($_POST['class_id']) && $_POST['class_id'] == $class['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($class['class_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small style="color:#888;">Required only if payment type is Class</small>
                                </div>
                                
                                <!-- Phone Number -->
                                <div class="form-group">
                                    <label for="phone_number">Phone Number</label>
                                    <input type="text" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($_POST['phone_number'] ?? ''); ?>" placeholder="Enter phone number">
                                </div>
                                
                                <!-- Reference Number -->
                                <div class="form-group">
                                    <label for="reference_number">Reference Number</label>
                                    <input type="text" id="reference_number" name="reference_number" value="<?php echo htmlspecialchars($_POST['reference_number'] ?? ''); ?>" placeholder="Leave blank to auto-generate">
                                </div>
                                
                                <!-- Status -->
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <select id="status" name="status">
                                        <option value="Completed" <?php echo (isset($_POST['status']) && $_POST['status'] === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                        <option value="Pending" <?php echo (isset($_POST['status']) && $_POST['status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="Failed" <?php echo (isset($_POST['status']) && $_POST['status'] === 'Failed') ? 'selected' : ''; ?>>Failed</option>
                                        <option value="Refunded" <?php echo (isset($_POST['status']) && $_POST['status'] === 'Refunded') ? 'selected' : ''; ?>>Refunded</option>
                                    </select>
                                </div>
                                
                                <!-- Payment Date -->
                                <div class="form-group">
                                    <label for="payment_date">Payment Date</label>
                                    <input type="datetime-local" id="payment_date" name="payment_date" value="<?php echo htmlspecialchars($_POST['payment_date'] ?? date('Y-m-d\TH:i')); ?>">
                                </div>
                                
                                <!-- Notes -->
                                <div class="form-group full-width">
                                    <label for="notes">Notes</label>
                                    <textarea id="notes" name="notes" rows="3" placeholder="Any additional notes..."><?php echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-save"></i> Add Payment
                                </button>
                                <button type="reset" class="btn btn-secondary">
                                    <i class="fas fa-undo"></i> Reset
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle Sidebar
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
        
        // Show/hide class selection based on payment type
        document.getElementById('payment_type').addEventListener('change', function() {
            const classGroup = document.getElementById('class_group');
            if (this.value === 'Class') {
                classGroup.style.display = 'block';
            } else {
                classGroup.style.display = 'none';
            }
        });
        
        // Trigger on page load
        document.addEventListener('DOMContentLoaded', function() {
            const paymentType = document.getElementById('payment_type').value;
            const classGroup = document.getElementById('class_group');
            if (paymentType === 'Class') {
                classGroup.style.display = 'block';
            } else {
                classGroup.style.display = 'none';
            }
        });
    </script>
</body>
</html>