<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script name
$current_page = basename($_SERVER['PHP_SELF']);

// Skip authentication for login page to avoid redirect loop
if ($current_page === 'login.php' || $current_page === 'register.php') {
    return;
}

// Check if user is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
    // Clear any output buffer
    if (ob_get_level()) ob_clean();
    
    // Store the requested URL to redirect back after login
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    
    // Redirect to login
    header('Location: login.php');
    exit;
}

// Optional: Check user role if needed
// if ($_SESSION['admin_role'] !== 'admin') {
//     header('Location: dashboard.php');
//     exit;
// }

// Refresh session timeout (optional)
// $_SESSION['last_activity'] = time();
?>