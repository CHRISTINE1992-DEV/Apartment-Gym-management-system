<?php
require_once 'config.php';

$user = currentUser();
$admin_name = $user['name'] ?? 'Admin';
$current_page = basename($_SERVER['PHP_SELF']);

// Get data for charts
// Members by membership type
$stmt = $pdo->query("SELECT membership_type, COUNT(*) as count FROM members GROUP BY membership_type");
$membership_data = $stmt->fetchAll();

$membership_labels = [];
$membership_counts = [];
foreach ($membership_data as $data) {
    $membership_labels[] = $data['membership_type'];
    $membership_counts[] = $data['count'];
}

// Monthly revenue for last 6 months
$stmt = $pdo->query("
    SELECT DATE_FORMAT(payment_date, '%b') as month, SUM(amount) as total 
    FROM payments 
    WHERE status = 'Completed' 
    AND payment_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(payment_date, '%b')
    ORDER BY payment_date
");
$revenue_data = $stmt->fetchAll();

$revenue_labels = [];
$revenue_amounts = [];
foreach ($revenue_data as $data) {
    $revenue_labels[] = $data['month'];
    $revenue_amounts[] = $data['total'];
}

// Class attendance
$stmt = $pdo->query("
    SELECT c.class_name, COUNT(cb.id) as bookings 
    FROM classes c
    LEFT JOIN class_bookings cb ON c.id = cb.class_id
    GROUP BY c.id
    LIMIT 5
");
$class_data = $stmt->fetchAll();

$class_labels = [];
$class_counts = [];
foreach ($class_data as $data) {
    $class_labels[] = $data['class_name'];
    $class_counts[] = $data['bookings'];
}

// Payment status
$stmt = $pdo->query("SELECT status, COUNT(*) as count FROM payments GROUP BY status");
$payment_status = $stmt->fetchAll();
$status_labels = array_column($payment_status, 'status');
$status_counts = array_column($payment_status, 'count');

// Total members count
$stmt = $pdo->query("SELECT COUNT(*) as total FROM members");
$total_members = $stmt->fetch()['total'];

// Total payments count and amount
$stmt = $pdo->query("SELECT COUNT(*) as total, SUM(amount) as total_amount FROM payments WHERE status = 'Completed'");
$payment_stats = $stmt->fetch();
$total_payments = $payment_stats['total'] ?? 0;
$total_revenue = $payment_stats['total_amount'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Hebron Apartment Gym MS</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f0f2f5;
        }
        
        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--dark);
            color: white;
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            transition: transform 0.3s ease;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header .logo {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-header .logo img {
            height: 40px;
            width: auto;
        }
        
        .sidebar-header .logo span {
            color: var(--red);
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .sidebar-nav ul {
            list-style: none;
        }
        
        .sidebar-nav li {
            margin-bottom: 5px;
        }
        
        .sidebar-nav .nav-section {
            color: rgba(255,255,255,0.3);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 20px 8px;
            font-weight: 700;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .sidebar-nav a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .sidebar-nav a.active {
            background: rgba(230, 57, 70, 0.15);
            color: white;
            border-left-color: var(--red);
        }
        
        .sidebar-nav a i {
            width: 24px;
            margin-right: 12px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #333;
            display: none;
        }
        
        .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-title i {
            color: var(--red);
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .notifications {
            position: relative;
            cursor: pointer;
        }
        
        .notifications .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--red);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 50%;
        }
        
        .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-info i {
            font-size: 20px;
            color: #666;
        }
        
        .user-info span {
            color: #333;
        }
        
        .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 8px 0;
            margin-top: 8px;
        }
        
        .user-dropdown:hover .dropdown-menu {
            display: block;
        }
        
        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.2s;
        }
        
        .dropdown-menu a:hover {
            background: #f5f5f5;
        }
        
        .dropdown-menu hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 5px 0;
        }
        
        /* Content Area */
        .content-area {
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .page-header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-header h1 i {
            color: var(--red);
        }
        
        /* Stats Bar */
        .stats-bar {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .stat-box {
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .stat-box .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }
        
        .stat-box .stat-info h4 {
            font-size: 20px;
            font-weight: 700;
            color: var(--dark);
            margin: 0;
        }
        
        .stat-box .stat-info p {
            font-size: 13px;
            color: #666;
            margin: 0;
        }
        
        /* Card */
        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        
        .card-header {
            padding: 18px 25px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: transparent;
        }
        
        .card-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }
        
        .card-header h3 i {
            color: var(--red);
            margin-right: 8px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* Chart containers */
        .chart-container {
            position: relative;
            height: 250px;
        }
        
        /* Row & Col */
        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }
        
        .col {
            min-width: 0;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .row {
                grid-template-columns: 1fr;
            }
            
            .stats-bar {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .stats-bar {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="../images/logo.png" alt="Tinah Gym Pro">
                    <span>Tinah Pro</span>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    
                    <li class="nav-section">Users</li>
                    <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                    <li><a href="manage_users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                    
                    <li class="nav-section">Classes</li>
                    <li><a href="manage_classes.php"><i class="fas fa-dumbbell"></i> Manage Classes</a></li>
                    
                    <li class="nav-section">Finance</li>
                    <li><a href="manage_payments.php"><i class="fas fa-credit-card"></i> Manage Payments</a></li>
                    <li><a href="add_payment.php"><i class="fas fa-plus-circle"></i> Add Payment</a></li>
                    
                    <li class="nav-section">Reports</li>
                    <li><a href="reports.php" class="active"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    
                    <li class="nav-section">Account</li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <nav class="top-navbar">
                <div class="navbar-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="page-title">
                        <i class="fas fa-chevron-right"></i> Reports & Analytics
                    </span>
                </div>
                
                <div class="navbar-right">
                    <div class="notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge">0</span>
                    </div>
                    
                    <div class="user-dropdown">
                        <div class="user-info">
                            <i class="fas fa-user-circle"></i>
                            <span><?php echo htmlspecialchars($admin_name); ?></span>
                            <i class="fas fa-chevron-down" style="font-size:12px;color:#999;"></i>
                        </div>
                        <div class="dropdown-menu">
                            <a href="#"><i class="fas fa-user"></i> Profile</a>
                            <a href="#"><i class="fas fa-cog"></i> Settings</a>
                            <hr>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Content Area -->
            <div class="content-area">
                <div class="page-header">
                    <h1><i class="fas fa-chart-bar"></i> Reports & Analytics</h1>
                </div>
                
                <!-- Stats Bar -->
                <div class="stats-bar">
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #4a90d9;">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h4><?php echo $total_members; ?></h4>
                            <p>Total Members</p>
                        </div>
                    </div>
                    
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #28a745;">
                            <i class="fas fa-file-invoice"></i>
                        </div>
                        <div class="stat-info">
                            <h4><?php echo $total_payments; ?></h4>
                            <p>Total Payments</p>
                        </div>
                    </div>
                    
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #17a2b8;">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-info">
                            <h4>Ksh<?php echo number_format($total_revenue, 2); ?></h4>
                            <p>Total Revenue</p>
                        </div>
                    </div>
                    
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #ffc107;">
                            <i class="fas fa-chart-pie"></i>
                        </div>
                        <div class="stat-info">
                            <h4><?php echo count($membership_data); ?></h4>
                            <p>Membership Types</p>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row 1 -->
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-users"></i> Members by Membership Type</h3>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="membershipChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-dollar-sign"></i> Monthly Revenue</h3>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="revenueChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row 2 -->
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-dumbbell"></i> Class Bookings</h3>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="classChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-chart-pie"></i> Payment Status</h3>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="paymentChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle Sidebar
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
        
        // Membership Chart
        const ctx1 = document.getElementById('membershipChart').getContext('2d');
        new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($membership_labels); ?>,
                datasets: [{
                    label: 'Members',
                    data: <?php echo json_encode($membership_counts); ?>,
                    backgroundColor: ['#4a90d9', '#28a745', '#ffc107', '#17a2b8', '#dc3545'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
        
        // Revenue Chart
        const ctx2 = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx2, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($revenue_labels); ?>,
                datasets: [{
                    label: 'Revenue ($)',
                    data: <?php echo json_encode($revenue_amounts); ?>,
                    backgroundColor: 'rgba(23, 162, 184, 0.2)',
                    borderColor: '#17a2b8',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
        
        // Class Chart
        const ctx3 = document.getElementById('classChart').getContext('2d');
        new Chart(ctx3, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($class_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($class_counts); ?>,
                    backgroundColor: ['#4a90d9', '#28a745', '#ffc107', '#17a2b8', '#dc3545'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        // Payment Status Chart
        const ctx4 = document.getElementById('paymentChart').getContext('2d');
        new Chart(ctx4, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($status_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($status_counts); ?>,
                    backgroundColor: ['#28a745', '#ffc107', '#dc3545', '#17a2b8'],
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html>