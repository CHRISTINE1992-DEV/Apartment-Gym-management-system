<?php
require_once 'config.php';

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = 'No member ID provided.';
    header('Location: manage_members.php');
    exit;
}

$id = (int)$_GET['id'];

// Get member details before deletion
$stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
$stmt->execute([$id]);
$member = $stmt->fetch();

if (!$member) {
    $_SESSION['error_message'] = 'Member not found.';
    header('Location: manage_members.php');
    exit;
}

// Handle deletion confirmation
if (isset($_POST['confirm_delete'])) {
    // Delete profile image if exists
    if (!empty($member['profile_image'])) {
        $image_path = UPLOAD_PATH . 'profiles/' . $member['profile_image'];
        if (file_exists($image_path)) {
            unlink($image_path);
        }
    }
    
    // Delete member from database
    $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
    $stmt->execute([$id]);
    
    $_SESSION['success_message'] = 'Member ' . htmlspecialchars($member['first_name'] . ' ' . $member['last_name']) . ' has been deleted successfully.';
    header('Location: manage_members.php');
    exit;
}

// Handle cancellation
if (isset($_POST['cancel'])) {
    header('Location: manage_members.php');
    exit;
}

$current_page = basename($_SERVER['PHP_SELF']);
$user = currentUser();
$admin_name = $user['name'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Member - Hebron Apartment Gym MS</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f0f2f5;
        }
        
        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--dark);
            color: white;
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            transition: transform 0.3s ease;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header .logo {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-header .logo img {
            height: 40px;
            width: auto;
        }
        
        .sidebar-header .logo span {
            color: var(--red);
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .sidebar-nav ul {
            list-style: none;
        }
        
        .sidebar-nav li {
            margin-bottom: 5px;
        }
        
        .sidebar-nav .nav-section {
            color: rgba(255,255,255,0.3);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 20px 8px;
            font-weight: 700;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .sidebar-nav a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .sidebar-nav a.active {
            background: rgba(230, 57, 70, 0.15);
            color: white;
            border-left-color: var(--red);
        }
        
        .sidebar-nav a i {
            width: 24px;
            margin-right: 12px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #333;
            display: none;
        }
        
        .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-title i {
            color: var(--red);
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .notifications {
            position: relative;
            cursor: pointer;
        }
        
        .notifications .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--red);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 50%;
        }
        
        .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-info i {
            font-size: 20px;
            color: #666;
        }
        
        .user-info span {
            color: #333;
        }
        
        .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 8px 0;
            margin-top: 8px;
        }
        
        .user-dropdown:hover .dropdown-menu {
            display: block;
        }
        
        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.2s;
        }
        
        .dropdown-menu a:hover {
            background: #f5f5f5;
        }
        
        .dropdown-menu hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 5px 0;
        }
        
        /* Content Area */
        .content-area {
            padding: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 80px);
        }
        
        /* Delete Card */
        .delete-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            padding: 50px;
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        
        .delete-icon {
            width: 100px;
            height: 100px;
            background: #fee2e2;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
        }
        
        .delete-icon i {
            font-size: 50px;
            color: var(--red);
        }
        
        .delete-card h2 {
            color: var(--dark);
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .delete-card .member-name {
            color: var(--red);
            font-weight: 700;
        }
        
        .delete-card .warning-text {
            color: #666;
            margin: 15px 0 25px;
            line-height: 1.8;
        }
        
        .delete-card .member-details {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }
        
        .delete-card .member-details .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        
        .delete-card .member-details .detail-row:last-child {
            border-bottom: none;
        }
        
        .delete-card .member-details .label {
            color: #666;
            font-weight: 500;
        }
        
        .delete-card .member-details .value {
            color: var(--dark);
            font-weight: 600;
        }
        
        .delete-card .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
            justify-content: center;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 30px;
            border: none;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
            font-size: 16px;
        }
        
        .btn-danger {
            background: var(--red);
            color: white;
        }
        
        .btn-danger:hover {
            background: #c62828;
            transform: scale(1.02);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: scale(1.02);
        }
        
        /* Alert */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            display: block;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .delete-card {
                padding: 30px 20px;
                margin: 20px;
            }
            
            .delete-card .btn-group {
                flex-direction: column;
            }
            
            .delete-card .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="../images/logo.png" alt="Tinah Gym Pro">
                    <span>Tinah Pro</span>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    
                    <li class="nav-section">Users</li>
                    <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                    <li><a href="manage_members.php" class="active"><i class="fas fa-users"></i> Manage Members</a></li>
                    
                    <li class="nav-section">Classes</li>
                    <li><a href="manage_classes.php"><i class="fas fa-dumbbell"></i> Manage Classes</a></li>
                    
                    <li class="nav-section">Finance</li>
                    <li><a href="manage_payments.php"><i class="fas fa-credit-card"></i> Manage Payments</a></li>
                    
                    <li class="nav-section">Reports</li>
                    <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    
                    <li class="nav-section">Account</li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <nav class="top-navbar">
                <div class="navbar-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="page-title">
                        <i class="fas fa-chevron-right"></i> Delete Member
                    </span>
                </div>
                
                <div class="navbar-right">
                    <div class="notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge">0</span>
                    </div>
                    
                    <div class="user-dropdown">
                        <div class="user-info">
                            <i class="fas fa-user-circle"></i>
                            <span><?php echo htmlspecialchars($admin_name); ?></span>
                            <i class="fas fa-chevron-down" style="font-size:12px;color:#999;"></i>
                        </div>
                        <div class="dropdown-menu">
                            <a href="#"><i class="fas fa-user"></i> Profile</a>
                            <a href="#"><i class="fas fa-cog"></i> Settings</a>
                            <hr>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Content Area -->
            <div class="content-area">
                <div class="delete-card">
                    <div class="delete-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    
                    <h2>Delete Member</h2>
                    <p class="warning-text">
                        Are you sure you want to delete <strong class="member-name"><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></strong>?
                        <br>
                        This action <strong>cannot be undone</strong> and will permanently remove all associated data.
                    </p>
                    
                    <div class="member-details">
                        <div class="detail-row">
                            <span class="label">Member ID</span>
                            <span class="value"><?php echo htmlspecialchars($member['member_id']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Full Name</span>
                            <span class="value"><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Email</span>
                            <span class="value"><?php echo htmlspecialchars($member['email']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Membership Type</span>
                            <span class="value"><?php echo htmlspecialchars($member['membership_type']); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Status</span>
                            <span class="value">
                                <span class="badge badge-<?php echo $member['membership_status'] === 'Active' ? 'success' : 'danger'; ?>">
                                    <?php echo htmlspecialchars($member['membership_status']); ?>
                                </span>
                            </span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Join Date</span>
                            <span class="value"><?php echo date('M d, Y', strtotime($member['join_date'])); ?></span>
                        </div>
                        <?php if ($member['membership_expiry']): ?>
                        <div class="detail-row">
                            <span class="label">Expiry Date</span>
                            <span class="value"><?php echo date('M d, Y', strtotime($member['membership_expiry'])); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <form method="POST" action="">
                        <div class="btn-group">
                            <button type="submit" name="confirm_delete" class="btn btn-danger" onclick="return confirm('Are you absolutely sure you want to delete this member? This action cannot be undone.')">
                                <i class="fas fa-trash"></i> Yes, Delete Member
                            </button>
                            <button type="submit" name="cancel" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle Sidebar
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
        
        // Double confirmation for delete
        document.querySelector('button[name="confirm_delete"]').addEventListener('click', function(e) {
            if (!confirm('WARNING: This will permanently delete this member and all their data. Are you sure?')) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>