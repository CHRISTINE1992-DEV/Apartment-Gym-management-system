<?php
require_once 'config.php';

// Log logout
if (isset($_SESSION['admin_id'])) {
    $logStmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, ip_address) VALUES (?, 'logout', ?)");
    $logStmt->execute([$_SESSION['admin_id'], $_SERVER['REMOTE_ADDR']]);
}

// Destroy session
session_destroy();

header('Location: login.php');
exit;
?>