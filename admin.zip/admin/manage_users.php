<?php
require_once 'config.php';

$user = currentUser();
$admin_name = $user['name'] ?? 'Admin';
$current_page = basename($_SERVER['PHP_SELF']);

// Handle search and filters
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$membership_filter = $_GET['membership'] ?? '';

$query = "SELECT * FROM members WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR member_id LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($status_filter)) {
    $query .= " AND membership_status = ?";
    $params[] = $status_filter;
}

if (!empty($membership_filter)) {
    $query .= " AND membership_type = ?";
    $params[] = $membership_filter;
}

$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$members = $stmt->fetchAll();

// Get counts for stats
$total_members = count($members);
$active_members = array_filter($members, function($m) { return $m['membership_status'] === 'Active'; });
$active_count = count($active_members);
$expired_members = array_filter($members, function($m) { return $m['membership_status'] === 'Expired'; });
$expired_count = count($expired_members);

// Get unique membership types for filter
$stmt = $pdo->query("SELECT DISTINCT membership_type FROM members ORDER BY membership_type");
$membership_types = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Hebron Apartment Gym MS</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --dark: #071d49;
            --light: #42a5f5;
            --red: #e53935;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f0f2f5;
        }
        
        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--dark);
            color: white;
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            transition: transform 0.3s ease;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header .logo {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .sidebar-header .logo img {
            height: 40px;
            width: auto;
        }
        
        .sidebar-header .logo span {
            color: var(--red);
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .sidebar-nav ul {
            list-style: none;
        }
        
        .sidebar-nav li {
            margin-bottom: 5px;
        }
        
        .sidebar-nav .nav-section {
            color: rgba(255,255,255,0.3);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 20px 8px;
            font-weight: 700;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .sidebar-nav a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .sidebar-nav a.active {
            background: rgba(230, 57, 70, 0.15);
            color: white;
            border-left-color: var(--red);
        }
        
        .sidebar-nav a i {
            width: 24px;
            margin-right: 12px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #333;
            display: none;
        }
        
        .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-title i {
            color: var(--red);
        }
        
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .notifications {
            position: relative;
            cursor: pointer;
        }
        
        .notifications .badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--red);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 50%;
        }
        
        .user-dropdown {
            position: relative;
            cursor: pointer;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-info i {
            font-size: 20px;
            color: #666;
        }
        
        .user-info span {
            color: #333;
        }
        
        .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background: white;
            min-width: 180px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 8px 0;
            margin-top: 8px;
        }
        
        .user-dropdown:hover .dropdown-menu {
            display: block;
        }
        
        .dropdown-menu a {
            display: block;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.2s;
        }
        
        .dropdown-menu a:hover {
            background: #f5f5f5;
        }
        
        .dropdown-menu hr {
            border: none;
            border-top: 1px solid #eee;
            margin: 5px 0;
        }
        
        /* Content Area */
        .content-area {
            padding: 30px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .page-header h1 {
            font-size: 28px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .page-header h1 i {
            color: var(--red);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 25px;
            border: none;
            border-radius: 40px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: var(--dark);
            color: white;
        }
        
        .btn-primary:hover {
            background: #0d2a4a;
            color: white;
        }
        
        .btn-secondary {
            background: var(--light);
            color: white;
        }
        
        .btn-secondary:hover {
            background: #1a8cd8;
            color: white;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
            color: white;
        }
        
        .btn-danger {
            background: var(--red);
            color: white;
        }
        
        .btn-danger:hover {
            background: #c62828;
            color: white;
        }
        
        .btn-sm {
            padding: 6px 15px;
            font-size: 12px;
        }
        
        /* Stats Bar */
        .stats-bar {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .stat-box {
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .stat-box .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }
        
        .stat-box .stat-info h4 {
            font-size: 20px;
            font-weight: 700;
            color: var(--dark);
            margin: 0;
        }
        
        .stat-box .stat-info p {
            font-size: 13px;
            color: #666;
            margin: 0;
        }
        
        /* Card */
        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* Filter Form */
        .filter-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            min-width: 200px;
            transition: border-color 0.3s;
        }
        
        .filter-group input:focus,
        .filter-group select:focus {
            border-color: var(--dark);
            outline: none;
        }
        
        /* Table */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .table thead th {
            background: #f8f9fa;
            font-weight: 600;
            color: #555;
            font-size: 13px;
            text-transform: uppercase;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .table-thumb {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        /* Badges */
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        
        .badge-danger {
            background: #f8d7da;
            color: #721c24;
        }
        
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .badge-info {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .text-center {
            text-align: center;
        }
        
        /* Alert */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .filter-group {
                flex-direction: column;
                width: 100%;
            }
            
            .filter-group input,
            .filter-group select {
                width: 100%;
                min-width: unset;
            }
            
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .stats-bar {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .stats-bar {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <img src="../images/logo.png" alt="Tinah Gym Pro">
                    <span>Hebron Apartment Gym MS</span>
                </div>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    
                    <li class="nav-section">Users</li>
                    <li><a href="add_member.php"><i class="fas fa-user-plus"></i> Add Member</a></li>
                    <li><a href="manage_users.php" class="active"><i class="fas fa-users"></i> Manage Users</a></li>
                    
                    <li class="nav-section">Classes</li>
                    <li><a href="manage_classes.php"><i class="fas fa-dumbbell"></i> Manage Classes</a></li>
                    
                    <li class="nav-section">Finance</li>
                    <li><a href="manage_payments.php"><i class="fas fa-credit-card"></i> Manage Payments</a></li>
                    
                    <li class="nav-section">Reports</li>
                    <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    
                    <li class="nav-section">Account</li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navbar -->
            <nav class="top-navbar">
                <div class="navbar-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="page-title">
                        <i class="fas fa-chevron-right"></i> Manage Users
                    </span>
                </div>
                
                <div class="navbar-right">
                    <div class="notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge">0</span>
                    </div>
                    
                    <div class="user-dropdown">
                        <div class="user-info">
                            <i class="fas fa-user-circle"></i>
                            <span><?php echo htmlspecialchars($admin_name); ?></span>
                            <i class="fas fa-chevron-down" style="font-size:12px;color:#999;"></i>
                        </div>
                        <div class="dropdown-menu">
                            <a href="#"><i class="fas fa-user"></i> Profile</a>
                            <a href="#"><i class="fas fa-cog"></i> Settings</a>
                            <hr>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Content Area -->
            <div class="content-area">
                <?php if (isset($_SESSION['success_message'])): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?php 
                        echo $_SESSION['success_message'];
                        unset($_SESSION['success_message']);
                        ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php 
                        echo $_SESSION['error_message'];
                        unset($_SESSION['error_message']);
                        ?>
                    </div>
                <?php endif; ?>
                
                <div class="page-header">
                    <h1><i class="fas fa-users"></i> Manage Users</h1>
                    <a href="add_member.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add New User
                    </a>
                </div>
                
                <!-- Stats Bar -->
                <div class="stats-bar">
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #4a90d9;">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h4><?php echo $total_members; ?></h4>
                            <p>Total Users</p>
                        </div>
                    </div>
                    
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #28a745;">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <div class="stat-info">
                            <h4><?php echo $active_count; ?></h4>
                            <p>Active Users</p>
                        </div>
                    </div>
                    
                    <div class="stat-box">
                        <div class="stat-icon" style="background: #dc3545;">
                            <i class="fas fa-user-times"></i>
                        </div>
                        <div class="stat-info">
                            <h4><?php echo $expired_count; ?></h4>
                            <p>Expired Users</p>
                        </div>
                    </div>
                </div>
                
                <!-- Filter -->
                <div class="card">
                    <div class="card-body">
                        <form method="GET" action="" class="filter-form">
                            <div class="filter-group">
                                <input type="text" name="search" placeholder="Search by name, email, ID..." value="<?php echo htmlspecialchars($search); ?>">
                                <select name="status">
                                    <option value="">All Status</option>
                                    <option value="Active" <?php echo $status_filter === 'Active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="Expired" <?php echo $status_filter === 'Expired' ? 'selected' : ''; ?>>Expired</option>
                                    <option value="Suspended" <?php echo $status_filter === 'Suspended' ? 'selected' : ''; ?>>Suspended</option>
                                    <option value="Cancelled" <?php echo $status_filter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <select name="membership">
                                    <option value="">All Membership</option>
                                    <?php foreach ($membership_types as $type): ?>
                                        <option value="<?php echo $type['membership_type']; ?>" <?php echo $membership_filter === $type['membership_type'] ? 'selected' : ''; ?>>
                                            <?php echo $type['membership_type']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i> Filter
                                </button>
                                <a href="manage_users.php" class="btn btn-secondary">
                                    <i class="fas fa-undo"></i> Reset
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Users Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Membership</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($members)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No users found</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($members as $member): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($member['member_id']); ?></td>
                                            <td>
                                                <?php if ($member['profile_image']): ?>
                                                    <img src="uploads/profiles/<?php echo htmlspecialchars($member['profile_image']); ?>" alt="Profile" class="table-thumb">
                                                <?php else: ?>
                                                    <div style="width: 40px; height: 40px; border-radius: 50%; background: #ddd; display: flex; align-items: center; justify-content: center;">
                                                        <i class="fas fa-user" style="color: #666;"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></strong>
                                            </td>
                                            <td><?php echo htmlspecialchars($member['email']); ?></td>
                                            <td><?php echo htmlspecialchars($member['phone'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($member['membership_type']); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo $member['membership_status'] === 'Active' ? 'success' : ($member['membership_status'] === 'Expired' ? 'danger' : 'warning'); ?>">
                                                    <?php echo $member['membership_status']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="btn btn-primary btn-sm" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="delete_member.php?id=<?php echo $member['id']; ?>" class="btn btn-danger btn-sm" title="Delete" onclick="return confirm('Are you sure you want to delete this member?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle Sidebar
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>